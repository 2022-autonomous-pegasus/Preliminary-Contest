#!/usr/bin/env python

import os

from cv2 import destroyAllWindows
import rospy

from Mission import Mission
from Database import Database
from Lanetracking import Lanetracking, perspectiveWarp

###

import time
import cv2
import numpy as np
from numpy.linalg import inv

###

CWD_PATH = os.getcwd()
cv2_window_3 = (640,0)


def getGD(canny):
    
    sobelx=cv2.Sobel(canny,cv2.CV_32F,1,0,ksize=1)
    sobely=cv2.Sobel(canny,cv2.CV_32F,0,1,ksize=1)
    theta = np.arctan(np.abs(sobely/(sobelx+1e-10)))*180/np.pi
    Amplitude = np.sqrt(sobelx**2+sobely**2)
    mask = (Amplitude>30).astype(np.float32)
    Amplitude = Amplitude*mask
    return Amplitude, theta


def sliding_window(img1, img2, patch_size=(100,302), istep=50):#, jstep=1, scale=1.0):

    Ni, Nj = (int(s) for s in patch_size)
    for i in range(0, img1.shape[0] - Ni+1, istep):
        patch = (img1[i:i + Ni, 39:341], img2[i:i + Ni, 39:341])
        yield (i, 39), patch


def predict(patches, DEBUG):

        #print(len(patches))
    labels = np.zeros(len(patches))
    index = 0
    for Amplitude, theta in patches:
        mask = (Amplitude>25).astype(np.float32)
        h, b = np.histogram(theta[mask.astype(np.bool)], bins=range(0,80,5))
        low, high = b[h.argmax()], b[h.argmax()+1]
        newmask = ((Amplitude>25) * (theta<=high) * (theta>=low)).astype(np.float32)
        value = ((Amplitude*newmask)>0).sum()

        if value > 1500:
            labels[index] = 1
        index += 1
        if(DEBUG):
            print(h) 
            print(low, high)
            print(value)
            cv2.imshow("newAmplitude", Amplitude*newmask)
            cv2.waitKey(1)
        
    return labels


# return 1 if crosswalk exists, 0 if it doesn't
def getlocation(indices, labels, Ni, Nj):

    zc = indices[labels == 1]
    if len(zc) == 0:
        return 0, None
    else:
        xmin = int(min(zc[:,1]))
        ymin = int(min(zc[:,0]))
        xmax = int(xmin + Nj)
        ymax = int(max(zc[:,0]) + Ni)
        return 1, ((xmin, ymin), (xmax, ymax))


# cross_walk
class Crosswalk(Mission):
    def __init__(self, db, lane_track):
        self.db = db
        self.lane_track = lane_track
        self.key = None
        time.sleep(2)

    def main(self):

        cam_data = self.db.camera_data
        hls = self.lane_track.hls
        canny = cv2.Canny(hls, 40, 60)
        birdView, birdViewL, birdViewR, minverse = perspectiveWarp(canny)
        DEBUG = False #if False, won't draw all step\
        
        Ni, Nj = (100, 302)
    
        if DEBUG:
            cv2.imshow("canny",canny)
    
        Amplitude, theta = getGD(birdView)
        if DEBUG:
            cv2.imshow("Amplitude", Amplitude)
            cv2.waitKey(1)

        ## Lanetracking.py ##
        
        # cv2.moveWindow("birdView",cv2_window_4[0],cv2_window_4[1])
        ## Lanetracking.py ##

        
        indices, patches = zip(*sliding_window(Amplitude, theta, patch_size=(Ni, Nj))) #use sliding_window get indices and patches
        labels = predict(patches, DEBUG) #predict zebra crossing for every patches 1 is zc 0 is background
        indices = np.array(indices)
        ret, location = getlocation(indices, labels, Ni, Nj)

        #draw
        if DEBUG:
            for i, j in indices[labels == 1]:
                cv2.rectangle(birdView, (j, i), (j+Nj, i+Ni), (0, 0, 255), 3)
 
        # crosswalk exists
        if ret:
            cv2.rectangle(birdView, location[0], location[1], (255, 0, 255), 3)
            angle = 0
            speed = 0
        else:
            # put original speed and angle
            angle = 0
            speed = 10

        cv2.imshow("img", birdView)
        cv2.waitKey(1)

        cv2.imshow("camera", cam_data)
        cv2.waitKey(1)
        
        return angle, speed
    
    def mission_end(self):

        if self.speed==0:
            time.sleep(3)
            return True
        else:
            return False

    def __str__(self):
        if self.key is None:
            return "None"
        else:
            return self.key + " Mission"


if __name__ == "__main__":
    db = Database()
    lane_track = Lanetracking(db)
    crosswalk_mission = Crosswalk(db, lane_track)
    rate = rospy.Rate(100)
    while not rospy.is_shutdown():
        car_angle, car_speed = lane_track.main()
        car_angle, car_speed = crosswalk_mission.main()
        # print(car_angle, car_speed)
        rate.sleep()