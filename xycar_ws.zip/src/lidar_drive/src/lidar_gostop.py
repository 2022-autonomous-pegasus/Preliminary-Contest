#!/usr/bin/env python

import rospy, time
from math import*
import numpy as np
from sensor_msgs.msg import LaserScan
from xycar_msgs.msg import xycar_motor

motor_msg = xycar_motor()
distance = None

def callback(data):
    global distance, motor_msg
    distance = data.ranges
    distance=list(distance)

def drive_go(data):
    global motor_msg
    motor_msg.speed = 5
    motor_msg.angle = data  #max = 45 maybe?
    pub.publish(motor_msg)

def drive_stop():
    global motor_msg
    motor_msg.speed = 0
    motor_msg.angle = 0
    pub.publish(motor_msg)
    time.sleep(1)

rospy.init_node('lidar_driver')
rospy.Subscriber('/scan', LaserScan, callback, queue_size = 1)
pub = rospy.Publisher('xycar_motor', xycar_motor, queue_size=1)

while distance is None:
    continue

rate = rospy.Rate(5)
motor_msg.angle = 0
pub.publish(motor_msg)
time.sleep(5)

while not rospy.is_shutdown():
    print(distance[2])
    for i in range(84,421):#46~314 angle 77 428
        distance[i]=0

    try:
        ok = 0
        a=[i for i in range(385,505)]+[i for i in range(127)]#front 385 595 127
        for degree in a:
            if (0.05 < distance[degree] <= 0.15):
                ok += 1
            if ok > 5:
                drive_stop()
                break

        dist_L=max(distance[0:84])#64
        dist_R=max(distance[421:])#443

        angle_L=distance.index(max(distance[0:84]))*0.713
        angle_R=distance.index(max(distance[421:]))*0.713
        
        
        x_L=dist_L*sin(pi*(angle_L/180))
        x_R=dist_R*sin(pi*(angle_R/180))
        y_L=dist_L*cos(pi*(angle_L/180))
        y_R=dist_R*cos(pi*(angle_R/180))
        #print(dist_L,dist_R)

        if (abs(dist_L-dist_R) < 1):
            steering_angle=0
        else:
            steering_angle=np.rad2deg(atan((y_L+y_R)/(x_L+x_R)))/2


        if ok <= 5:
            if (abs(dist_L-dist_R) < 1):
                drive_go(steering_angle)
            else:
                drive_go(steering_angle)

    except: pass
    #print(steering_angle)


    rate.sleep()
