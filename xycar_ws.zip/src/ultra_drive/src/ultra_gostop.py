#!/usr/bin/env python

import rospy, time
from math import*
import numpy as np
from std_msgs.msg import Int32MultiArray
from xycar_msgs.msg import xycar_motor

ultra_msg = None
motor_msg = xycar_motor()

def ultra_callback(data):
    global ultra_msg
    ultra_msg = data.data 

def drive_go(data1,data2):
    global motor_msg, motor_publisher
    motor_msg.speed = data1
    motor_msg.angle = data2
    pub.publish(motor_msg)

def drive_stop(data):
    global motor_msg, ack_publisher
    motor_msg.speed = 0
    motor_msg.angle = data
    pub.publish(motor_msg)
 
rospy.init_node('ultra_driver')
rospy.Subscriber("xycar_ultrasonic", Int32MultiArray, ultra_callback)
pub = rospy.Publisher('xycar_motor', xycar_motor, queue_size=1)

time.sleep(3) #ready to connect
#ultra_msg[0] = left
#ultra_msg[4] = right
drive_go(0,0)
time.sleep(8)
ok=0
while not rospy.is_shutdown():
    '''a=45.0
    L=33.5
    r=2
    R=L/sin(pi*(a/180))+r'''
    #print(ultra_msg[4],ultra_msg[5])
    if (ok==0):
        drive_go(3,0)
        if (ultra_msg[4]>70):
            while 1:
                drive_go(3,0)
                if (ultra_msg[5]<90) and (ultra_msg[4]<40):
                    ok=1
                    break
    if (ok==1):
        if (abs(ultra_msg[0]-ultra_msg[4])<0.5):
            drive_go(-3,0)
        elif (abs(ultra_msg[0]-ultra_msg[4])>0.5):
            drive_go(-3,45)
    if (ultra_msg[6] > 0 and ultra_msg[6] < 15) or (ok==2):
        if ok==1:
            drive_stop(0)
            time.sleep(3)
        drive_go(3,45)
        ok=2
