#!/usr/bin/env python

import rospy
import time
from sensor_msgs.msg import LaserScan

lidar_points = None

def lidar_callback(data):
    global lidar_points
    lidar_points = data.ranges

rospy.init_node('Lidar', anonymous=True)
rospy.Subscriber("/scan", LaserScan, lidar_callback, queue_size=1)

while not rospy.is_shutdown():
    if lidar_points == None:
        continue
    
    rtn = ""
    for i in range(12):
        rtn += str(format(lidar_points[i*30],'.2f')) + ", "
    # print(rtn[:-2])
    # print(lidar_points[0], lidar_points[1], lidar_points[2], lidar_points[3], lidar_points[4])
    print(lidar_points[500], lidar_points[501], lidar_points[502], lidar_points[503], lidar_points[504])
    print("len", len(lidar_points))
    time.sleep(0.5)   
